2020.01.14
	�[�J�����s���s�A���t�X�����s�Ƶ{������C
	keywords.txt
		setSaveConfigCallback KEYWORD2
	WiFiManager.h
		<br/><form action=\"eupdate\" method=\"post\"><button>EWC Update</button></form>
		//�]�w�����s�^�I�禡
    	void setEWCUpdateCallback( void (*func)(void) );
		void handleEWCUpdate();
		void (*_ewcupdatecallback)(void) = NULL;
	WiFiManager.cpp
		server->on(String(F("/eupdate")).c_str(), std::bind(&WiFiManager::handleEWCUpdate, this));  //�����s
		/** Handle the EWC �����s page */
		void WiFiManager::handleEWCUpdate() {
			String page = FPSTR(HTTP_HEADER);
			page.replace("{v}", "EWC_Update");
			page += F("Please wait for restart...");
			page += FPSTR(HTTP_END);
			server->sendHeader("Content-Length", String(page.length()));
			server->send(200, "text/html", page);
			delay(3000);
			if ( _ewcupdatecallback != NULL) {
				DEBUG_WM(F("EWC Update"));
				_ewcupdatecallback();
				delay(2000);
			}
			DEBUG_WM(F("EWC Update right"));
		}
		//EWC �����s callback
		void WiFiManager::setEWCUpdateCallback( void (*func)(void) ) {
		  _ewcupdatecallback = func;
		}
